class Greeting {
    static {
        com.github.fommil.jni.JniLoader.load("libgreeting.so");
    }

    public static void main(String[] args) {
        Greeting.greeting();
    }

    public static native void greeting();
}
