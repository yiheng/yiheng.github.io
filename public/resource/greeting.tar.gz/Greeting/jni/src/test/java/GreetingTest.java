import org.junit.Test;

public class GreetingTest {
    @Test
    public void testGreeting() {
        Greeting.greeting();
    }
}
